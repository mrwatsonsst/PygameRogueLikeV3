class Action:
    pass


class EscapeAction(Action):
    pass

class MovementAction(Action):
    def _init_(self, dx: int, dy: int):
        super()._init_()

        self.dx = dx
        self.dy = dy